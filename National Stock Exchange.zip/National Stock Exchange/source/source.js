var Shareholders = {};
(function(){
var rcp = 0; // research complete
var stse = false;
var sosh = 0; // sold shares
var ys = 0; // 
var gcgd;
var tss = 0;
var shareValue;
var shareAmount;
var amountOfShares;
var dividendPercentage = 1;
var maxValue;
var n;
	
UltimateLib.Research.addRndResearch({
	id: "NSEID",
	name: "National Stock Exchange",
	pointsCost: 1000,
	iconUri: GDT.getRelativePath() + 'images/NSElogo.jpg',
	description: "This will unlock the ability to sell shares on the National Stock Exchange and create extra cash for your upcoming projects",
	canResearch: function () {
							var res = true;
							res &= GameManager.company.flags.rndLabUnlocked & GameManager.company.cash > 5E7;

						return res;
				},
	repeatable: false,
	targetZone: 2,
	complete: function () {
			var research =  Research.getAllItems().filter(function (f) { return f.id === 'c0956353-4012-4983-9576-22e515e14f69';  });
			if(research){
				GameManager.company.researchCompleted.push(research);
				var notification = new Notification({
					header: "National Stock Exchange",
					text: "You have now unlocked the ability to sell shares. Click on the screen to go to the National Stock Exchange.",
					image: "",
					buttonText: "OK",
					weeksUntilFired: 0
				});
				GameManager.company.notifications.push(notification);
				rcp = 1;
				GDT.getDataStore("NSE").data.rcpd = rcp;
			}
			else {
				var notification = new Notification({
					header: "UME Error",
					text: "An error occurred on lab research complete callback.",
					image: "",
					buttonText: "OK",
					weeksUntilFired: 0
				});
				GameManager.company.notifications.push(notification);
			}
			
	}
})
if(GDT.getDataStore("NSE").data.rcpd = 1) {
		 
	UI.SellShares = function (a) {
		Sound.click();
		switch (a.id) {
			case "SellShares":
				sharesSell();
				break;
			case "CancSS":
				clickCancel();
				break;
			case "CancSS1":
				clickCancel();
				break;
			case "BAS":
				buyAllShares();
				break;
			case "Bbond1":
				buyBond1();
				break;
			/*case "Bbond2":
				buyBond2();
				break;
			case "Bbond3":
				buyBond3();
				break;
			case "Bbond4":
				buyBond4();
				break;*/
			default:
				return;
		}
	};
	
	
	var div = $("body");
	div.append('<div id="NatStockEx" class="windowBorder wideWindow" style="overflow:auto;display:none;"> <div id="toNSE" class="windowTitle smallerWindowTitle">National Stock Exchange</div>');
	div = $("#NatStockEx"); 
	div.append('<div id="CancSS" class="selectorButton whiteButton" onclick="UI.SellShares(this)" style="margin-left:50px;width: 675px">Cancel</div>');
	div.append('<div style="text-align:center;margin-left:50px;width: 675px">Welcome to the National Stock Exchange!<BR />Here you can sell shares to unknown investors. Your current cash indicates the value of each share.<BR />How many shares would you like to sell?</div>');
	div.append('<div id="NSEinfo" class="windowTitle smallerWindowTitle">Share Market</div>');
	div.append('<div id="SV" style="text-align:center;margin-left:50px;width:675px;heigth:50px"></div>'); //ShareValue
	div.append('<div id="MAOS" style="text-align:center;margin-left:50px;width:675px;heigth:50px"></div>'); //MaxAmountOfShares
	div.append('<div id="AmountOfShares" style="text-align:center;margin-left:50px;width:675px;height:50px"></div>');
	div.append('<div class="SAS"></div>');
	div.append('<div id="TotalIncome" style="text-align:center;margin-left:50px;width:675px;height:50px"></div>');
	div.append('<div id="SellShares" class="selectorButton whiteButton" onclick="UI.SellShares(this)" style="margin-left:50px;width: 675px">Sell Shares</div>');
	div.append('<div id="BAS" class="selectorButton whiteButton" onclick="UI.SellShares(this)" style="margin-left:50px;width: 675px">Buy All Shares Back</div>');
	div.append('<div id="NSEbonds" class="windowTitle smallerWindowTitle">Bond Market</div>');
	div.append('<div id="Bbond1" class="selectorButton whiteButton" onclick="UI.SellShares(this)" style="margin-left:50px;width: 675px">Telecomina Inc. | Price; 5M | 7% interest | 5 years</div>');
	//div.append('<div id="Bbond2" class="selectorButton whiteButton" onclick="UI.SellShares(this)" style="margin-left:50px;width: 675px">Tari Industries | Price; 10M | 5% interest | 5 years</div>');
	//div.append('<div id="Bbond3" class="selectorButton whiteButton" onclick="UI.SellShares(this)" style="margin-left:50px;width: 675px">Vize Electronics | Price; 50M | 4% interest | 7 years</div>');
	//div.append('<div id="Bbond4" class="selectorButton whiteButton" onclick="UI.SellShares(this)" style="margin-left:50px;width: 675px">Government | Price; 100M | 2% interest | 10 years</div>');
	div.append('<div id="CancSS1" class="selectorButton whiteButton" onclick="UI.SellShares(this)" style="margin-left:50px;width: 675px">Cancel</div>');
	
	
	var b1a;
	var yb;
	var b2a;
	var b3a;
	var b4a;
	function buyBond1() {
		if (GDT.getDataStore("NSE").data.b1a == 1) {
			div.dialog("close");
			GameManager.resume(true);
			var n = new Notification({
				header: "National Stock Exchange".localize(),
				text: "You have already bought this bond. You have to wait until they repay you fully (which will take {0} years) to buy this bond again.".localize().format(GDT.getDataStore("NSE").data.yb - gcgd.year + 5),
				buttonText: "OK"
			})
			GameManager.company.notifications.push(n)
		}
		else {
			var c = 5E6;
			GameManager.company.adjustCash(-c, "Telecomina Inc. Bond")
			div.dialog("close");
			GameManager.resume(true);
			b1a = 1;
			GDT.getDataStore("NSE").data.b1a = b1a;
			yb = GameManager.company.getDate(GameManager.company.currentWeek).year
			GDT.getDataStore("NSE").data.yb = yb;
		}
	};
	
	function iBond1() {
		if (GDT.getDataStore("NSE").data.b1a == 1) {
		gcgd = GameManager.company.getDate(GameManager.company.currentWeek);
			if ((gcgd.year == GDT.getDataStore("NSE").data.yb + 1 && gcgd.month == 1 && gcgd.week == 1) || (gcgd.year == GDT.getDataStore("NSE").data.yb + 2 && gcgd.month == 1 && gcgd.week == 1) || (gcgd.year == GDT.getDataStore("NSE").data.yb + 3 && gcgd.month == 1 && gcgd.week == 1) || (gcgd.year == GDT.getDataStore("NSE").data.yb + 4 && gcgd.month == 1 && gcgd.week == 1)) {
				var i1 = 5E6 / 5 * 1.07;
				GameManager.company.adjustCash(i1, "Bond Repayment");
			}
			else if(gcgd.year == GDT.getDataStore("NSE").data.yb + 5 && gcgd.month == 1 && gcgd.week == 1) {
				var i1 = 5E6 / 5 * 1.07;
				GameManager.company.adjustCash(i1, "Bond Repayment");
				GDT.getDataStore("NSE").data.b1a = 0;
			}
		}
	};
	iBond1();
	GDT.on(GDT.eventKeys.gameplay.weekProceeded, iBond1);
	
	function valueShares() { // Value of each share
		shareValue = Math.floor(GameManager.company.cash / 500000000 * 20);
		div.find("#SV").html("Value per share: " + shareValue);	
	};
	
	function MaxShares() { // Max amount of shares that can be sold
		shareValue = Math.floor(GameManager.company.cash / 500000000 * 20);
		var maxAmount = Math.round(GameManager.company.cash / shareValue);
		div.find("#MAOS").html("Maximum amount of shares: " + maxAmount);
	}; 
	
	function totalShares(z) {
		amountOfShares = z;
		div.find("#AmountOfShares").html("Amount of shares selected to sell: " + amountOfShares);
		shareValue = Math.floor(GameManager.company.cash / 500000000 * 20);
		var s = amountOfShares * shareValue;
		div.find("#TotalIncome").html("Total income: " + Math.round(s / 1E6) + "M");
	};
	
	
	function sharesSell() {
		gcgd = GameManager.company.getDate(GameManager.company.currentWeek);
		if(gcgd.year - 1 < GDT.getDataStore("NSE").data.ys && GDT.getDataStore("NSE").data.ys != 0 && GDT.getDataStore("NSE").data.sosh == 1) {
			div.dialog("close")
			GameManager.resume(true)
			n = new Notification({
				header: "General Meeting of Shareholders".localize(),
				text: "The General Meeting of Shareholders have decided that they do not want this company to hold a second emission yet. Therefore no shares have been sold.".localize(),
				buttonText: "OK"
			});
			GameManager.company.notifications.push(n)
		}
		else {
			shareValue = Math.floor(GameManager.company.cash / 500000000 * 20);
			var s = Math.floor(amountOfShares * shareValue);
			GameManager.company.adjustCash(s, "Shares Sales")
			if (isNaN(GDT.getDataStore("NSE").data.tss)) {
				GDT.getDataStore("NSE").data.tss = s;
			}
			else {
				GDT.getDataStore("NSE").data.tss = GDT.getDataStore("NSE").data.tss + s;
			}
			div.dialog("close")
			sosh = 1;
			GDT.getDataStore("NSE").data.sosh = sosh;
			ys = GameManager.company.getDate(GameManager.company.currentWeek).year;
			GDT.getDataStore("NSE").data.ys = ys;
			GameManager.resume(true)
			n = new Notification({
				header: "News".localize(),
				text: "In a recent announcement, {0} have stated that they have decided to sell their shares on the National Stock Exchange. Witnesses state that all of their shares have been sold out within minutes.".localize().format(GameManager.company.name),
				buttonText: "OK!"
			});
			GameManager.company.notifications.push(n)
		
		}
	};
	function clickCancel() {
		div.dialog("close");
		GameManager.resume(true);
	};		
	
	function buyAllShares() {
		if (GDT.getDataStore("NSE").data.sosh == 1) {
			var c = GDT.getDataStore("NSE").data.tss;
			if (c > GameManager.company.cash) {
				div.dialog("close");
				GameManager.resume(true);
				n = new Notification({
					header: "National Stock Exchange".localize(),
					text: "We're sorry, but you do not have the sufficient funds to make this transaction. Please try again once you do.".localize(),
					buttonText: "OK!"
				})
				GameManager.company.notifications.push(n)
			}
			else {
				GameManager.company.adjustCash(-c, "Shares buyback");
				div.dialog("close");
				GDT.getDataStore("NSE").data.sosh = 0;
				GDT.getDataStore("NSE").data.tss = 0;
				GameManager.resume(true);
				n = new Notification({
					header: "News".localize(),
					text: "In a shocking turn of events, {0} have announced that they have bought of their shares off the market. This has cost them a whopping {1}M".localize().format(GameManager.company.name, Math.round(c / 1E6)),
					buttonText: "OK!"
				})
				GameManager.company.notifications.push(n)
			}
		}
	};
	
	function dividendC() {
		if(GDT.getDataStore("NSE").data.sosh = 1) {
			var min = 0.115, max = 0.185
			var d = (Math.floor(Math.random() * (max - min + 1)) + min) * GDT.getDataStore("NSE").data.tss;
			gcgd = GameManager.company.getDate(GameManager.company.currentWeek);
			if (gcgd.month == 1 && gcgd.week == 1) {
				GameManager.company.adjustCash(-d, "Dividend Payout")
				n = new Notification({
					header: "Finance Report".localize(),
					text: "The dividend over last year has been paid. The shareholders have received a total sum of {0}M and have dividided it accordingly.".localize().format(Math.round(d / 1E6)),
					buttonText: "OK!"
				});
				GameManager.company.notifications.push(n)
			}				
		}
	};

	GDT.on(GDT.eventKeys.gameplay.weekProceeded, dividendC);
		var OriginalContextMenu = UI.showContextMenu;
    	var NewContextMenu = function (items, mouseloc) {
    		items.push({
    			label: "National Stock Exchange...",
    			action: function () {
    				Sound.click();
    				GameManager.resume(false);
    				var div = $("#NatStockEx");
    				div.scrollTop()
    				div.gdDialog({
    					popout: !0,
    					close: !0,
					})
				}
    		});
			shareValue = Math.floor(GameManager.company.cash / 500000000 * 20);
			shareAmount = Math.round(GameManager.company.cash / shareValue);
			maxValue = Math.floor(GameManager.company.cash / (GameManager.company.cash / 500000000 * 20)); 
    			div.find(".SAS").slider({
    				min: 1,
    				max: maxValue,
    				range: "min",
    				value: shareAmount,
    				animate: !1,
    				slide: function (a, b) {
    					var c = b.value;
    					totalShares(c);
    				}
    			});
    		totalShares(shareAmount);
			valueShares();
			MaxShares();
			OriginalContextMenu(items, mouseloc);
    	};
    	UI.showContextMenu = NewContextMenu; 
};
})(); 



