var NSE_Pastract = {};

(function(){
	NSE_Pastract.path = GDT.getRelativePath();
	var ready = function () {
	};

	var error = function () {
	};

GDT.loadJs(['source/source.js'], ready, error);

})();
